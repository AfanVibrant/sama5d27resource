The schematics and PCB design files were created with Cadence Orcad and Allegro EDA tools.
The PCB layouts were then converted into Altium PcbDoc & PcbPrj with some Cadence conversion facility. 

Although we think we made the job right, we cannot guarantee these Altium design files are 100% equivalent to design files that would have been created from scratch with Altium EDA tools. Therefore we recommend you reuse those Altium design files with adequate precaution and double-checking.